<script type="text/javascript">
  var pathname = window.location.pathname; 
  window.location.replace(`https://www.crazyforcakes.com.br/${pathname}`);
</script>


<!-- API Crazy For Cakes -->